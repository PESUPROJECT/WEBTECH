<html>

<head>


<style>


.button {
  font: bold 30px COPPERPLATE GOTHIC BOLD;
  text-decoration: none;
  background-color: green;
  color: white;
  padding: 5px 10px 5px 10px;
  border-top: 1px solid #CCCCCC;
  border-right: 1px solid #333333;
  border-bottom: 1px solid #333333;
  border-left: 1px solid #CCCCCC;
}
* {
    box-sizing: border-box;
}

body {
    font-family: Arial, Helvetica, sans-serif;
}


header {
    padding: 30px;
    text-align: center;
    font-size: 50px;
    font-family: 'comic sans';
    color: white;
}



nav {
    float: left;
    width: 30%;
    
    padding: 20px;
}


article {
    float: left;
    font-size: 24;
    font-family: 'COPPERPLATE GOTHIC BOLD';
    color: white;
    padding: 10px;
    width: 65%;
   
}


section:after {
    content: "";
    
    clear: both;
}


.form-popup {
  display: none;
  position: fixed;
  bottom: 0;
  right: 15px;
  border: 3px solid #f1f1f1;
  z-index: 9;
}


.form-container {
  max-width: 300px;
  padding: 10px;
  background-color: white;
}


.form-container input[type=text], .form-container input[type=password] {
  width: 100%;
  padding: 15px;
  margin: 5px 0 22px 0;
  border: none;
  background: #f1f1f1;
}


.form-container input[type=text]:focus, .form-container input[type=password]:focus {
  background-color: #ddd;
  outline: none;
}


.form-container .btn {
  background-color: #4CAF50;
  color: white;
  padding: 16px 20px;
  border: none;
  cursor: pointer;
  width: 100%;
  margin-bottom:10px;
  opacity: 0.8;
}


.form-container .cancel {
  background-color: red;
}


.form-container .btn:hover, .open-button:hover {
  opacity: 1;
}
</style>
<link rel="stylesheet" href="common.css">

<script type="text/javascript">
function complaint(){
document.
  }
</script>
</head>
<body>
<script>
    function openForm() {
    document.getElementById("myForm").style.display = "block";
      }

    function closeForm() {
    document.getElementById("myForm").style.display = "none";
    }
    function logout() {
    window.open("try2new.html");
    }
    function noti(){

      open("noti.php");
}
</script>

<header>
  <h2><font color="orange">Welcome to RPS!</font></h2>
</header>

<section>
  <nav>
    <ul type="none">
      <li><br><br><br><br><br>
        <button class="button" onclick="noti()">Show Notification</button>

    </li>      
      <br>
      <li>
      <button class="button" onclick="openForm()">Submit Complaint</button><br><br>
      <div class="form-popup" id="myForm">
      <form method="post" action="" class="form-container">
      <font color="black">Enter your name</font><input type="text" name="namee"><br>
      <font color="black">Complaint</font><br>
      <textarea rows="10" cols="36" name="comp"></textarea>
      <button type="submit" class="btn">Submit</button>
      <button type="button" class="btn cancel" onclick="closeForm()">Close</button>
    </form>
  </div>
</li>
<?php
 
  if(array_key_exists('namee',$_POST) && $_POST['namee']!=""){
       $d=$_POST['namee'];
      }
      else{
        $d=" ";
      }
      if(array_key_exists('comp',$_POST) && $_POST['comp']!=""){
      $no=$_POST['comp'];
    }
    else{
      $no=" ";
    }
     $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "Members";

    
    $conn = mysqli_connect($servername, $username, $password,$dbname);
    if(! $conn ) {
      die('Could not connect: ' . mysqli_connect_error());
    }
    $sql = "UPDATE details SET Complaint='$no' WHERE Name='$d'";
   
    mysqli_query($conn,$sql);
   
 
 mysqli_close($conn);
 $f=fopen("complaints.txt","a");
 fwrite($f,$d);
 fwrite($f,"\n");
 fwrite($f,$no);
 fwrite($f,"\n");
 fclose($f);
?>


  <li><button class="button" onclick="logout()">Logout</button>
      
    </ul>
  </nav>
  <br><br><br><br><br>
  <article id="art">
    <font color="white" face="COPPERPLATE GOTHIC BOLD" size= 8><b>A Note to the members...</b></font>
    <p>We are acutely conscious of the fact that due to rapid urbanization, there are huge challenges and as responsible real estate player we shall continue to provide intelligent solutions in a manner which is sustainable. We rely on our people, their capacities to innovate and use of technology to create immense value for all our stakeholders. We will continue to raise the bar and set new standards in the industry to strengthen this goal of ours.
    </font>
  </p>
  </article>
</section> 

 </form>


</body>
</html>
