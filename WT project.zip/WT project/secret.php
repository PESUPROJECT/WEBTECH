<!DOCTYPE html><head>

<style>

body {
    font-family: Arial, Helvetica, sans-serif;
}


header {
    padding: 10px;
    text-align: center;
    font-size: 50px;
    font-family: 'comic sans';
    color: white;
}

nav {
    float: left;
    width: 30%;
    
    padding: 20px;
}


article {
    float: left;
    font-size: 36px;
    font-family: 'COPPERPLATE GOTHIC BOLD';
    color: white;
    padding: 20px;
    width: 65%;
 
}


section:after {
    content: "";
    clear: both;
}


.form-popup {
  display: none;
  position: fixed;
  bottom: 0;
  right: 15px;
  border: 3px solid #f1f1f1;
  z-index: 9;
}


.form-container {
  max-width: 300px;
  padding: 10px;
  background-color: white;
}


.form-container input[type=text], .form-container input[type=password] {
  width: 100%;
  padding: 15px;
  margin: 5px 0 22px 0;
  border: none;
  background: #f1f1f1;
}


.form-container input[type=text]:focus, .form-container input[type=password]:focus {
  background-color: #ddd;
  outline: none;
}


.form-container .btn {
  background-color: #4CAF50;
  color: white;
  padding: 16px 20px;
  border: none;
  cursor: pointer;
  width: 100%;
  margin-bottom:10px;
  opacity: 0.8;
}


.form-container .cancel {
  background-color: red;
}


.form-container .btn:hover, .open-button:hover {
  opacity: 1;
}
.button {
  font: bold 30px COPPERPLATE GOTHIC BOLD;
  text-decoration: none;
  background-color: green;
  color: white;
  padding: 5px 10px 5px 10px;
  border-top: 1px solid #CCCCCC;
  border-right: 1px solid #333333;
  border-bottom: 1px solid #333333;
  border-left: 1px solid #CCCCCC;
}
</style>
<link rel="stylesheet" href="common.css">

</head>
<body>

<script>
    function openForm() {
    document.getElementById("myForm").style.display = "block";
      }

    function closeForm() {
    document.getElementById("myForm").style.display = "none";
    }
    function logout() {
    window.open("try2new.html");
    }
    function newpage(){
      window.open("notifications.php")
    }

</script>
<header>
  <h2><font face="COPPERPLATE GOTHIC BOLD">Welcome</font></h2>
</header>
<?php
$f1=fopen("complaints.txt","r");
$x=fread($f1,100);
fclose($f1);
?>
<section>
  <nav>
      <ul type="none">
      <li><br><br><br><br><br><br>
        <button id="notification-trigger" class="button" onclick="newpage()">
           Show New Notifications
          </button></li><br><br>
      <li><button class="button" onclick="openForm()">Post Notifications</button></li><br><br>
      <div class="form-popup" id="myForm">
      <form method="post" action="" class="form-container">
      <textarea rows="10" cols="36" name="notii" value=" "></textarea>
      <button type="submit" class="btn">Submit</button>
      <button type="button" class="btn cancel" onclick="closeForm()">Close</button>
    </form>
  </div>
      <li><button class="button" onclick="logout()">Logout</button>
      </li>
    </ul>
  </nav>
     
  <?php
  $f=fopen("notifications.txt","a");
  if(array_key_exists('notii',$_POST) && $_POST['notii']!=""){
       $d=$_POST['notii'];
      }
      else{
        $d=" ";
      }
 
  fwrite($f,$d);
  fwrite($f,"\n");
  fclose($f);

  ?>
  
  <article id="art">
    <p>
      <font color="orange">Vision</font><br>
      Transform the way people perceive 'Quality'<br><br>
      
      <font color="orange">Mission</font><br>
      No shortcuts to Quality<br><br>
      
      <font color="orange">Philosophy</font><br>
      Passion at Work<br>
  
  </p>
  </article>
  
</section>

 </form>


</body>
</html>