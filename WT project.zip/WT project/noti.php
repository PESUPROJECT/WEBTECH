<!DOCTYPE html>
<html>
<head>
<style type="text/css">
    body {
    
    background-image: url("b.jpg");
    height: 100%; 
    width: 100%;
    background-size: cover;
    background-position:all;
    background-repeat:repeat;
}
</style>

</head>
<body>
<?php
$f3=fopen("notifications.txt","r");
$fs=filesize("notifications.txt");


while(!feof($f3)){
    $a=fgets($f3);
    echo "<font color='orange' size=15 face='Comic Sans MS'>".$a."<br>"."</font>";
    echo "<br>";
}
fclose($f3);
?>
</body>
</html>
