<!DOCTYPE html>
<html>
<head>

  <style>
    
  .bg {
    
    background-image: url("b.jpg");
    height: 100%; 
    width: 100%;

    background-position: center;
    background-repeat: no-repeat;
    background-size: cover;

}
body, html {
    height: 100%;
    margin: 0;
}
.container {
   
    background-color: rgb(0,0,0); 
  background-color: rgba(0,0,0, 0.4); 
  color: white;
  font-weight: bold;
  border: 3px solid #f1f1f1;
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
  z-index: 2;
  width: 30%;
  padding: 20px;
  text-align: center;
}
.btn {
    background-color: #4CAF50;
    color: white;
    padding: 16px 20px;
    border: none;
    cursor: pointer;
    width: 30%;
    height: 20%;
    opacity: 0.9;
}

.btn:hover {
    opacity: 1;
}
*{
    box-sizing: border-box;
}

input[type=text],input[type=password],input[type=email]{
width:100%;
padding: 15px;
margin:5px 0px 22px 0px;
border:none;
background: #f1f1f1;
  
}

input[type=text]:focus,input[type=password],input[type=email]:focus{
background-color: #ddd;
outline:none;}


.button {
  font: bold 30px COPPERPLATE GOTHIC BOLD;
  text-decoration: none;
  background-color: green;
  color: white;
  padding: 5px 10px 5px 10px;
  border-top: 1px solid #CCCCCC;
  border-right: 1px solid #333333;
  border-bottom: 1px solid #333333;
  border-left: 1px solid #CCCCCC;
}

</style>

</head>

<?php

if(isset($_POST['submit_pass']) && $_POST['pass'])
{
 $pass=$_POST['pass'];
 if($pass=="RPS")
 {
  $_SESSION['password']=$pass;
 }
 else
 {
  $error="Incorrect Password";
 }
}

if(isset($_POST['page_logout']))
{
 unset($_SESSION['password']);
}
?>


<body>
<div class="bg">
<?php

if($_SESSION['password']=="RPS")
{
 ?>
 <br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
 <p align="center">
 <a href="trymember.php" class="button">Want to login as a member?</a><br><br><br><br><br><br><br>
 <a href="try2new.html" class="button"> Go to home </a>
</p>
 <?php
}
else
{
 ?>
 <form method="post" id="login_form" class="container" style="float:center" style="margin:3">
    <font size=8 >Login</font>
    <br><br><br><br>
    <label for="psw"><b><font face="COPPERPLATE GOTHIC BOLD" size=6 >Password</font></b></label>
    <input type="password" name="pass" placeholder="*******"><br><br>
  
    <button type="submit" name="submit_pass" class="btn" value="DO SUBMIT"><font size=5 >Login</font></button>
    <!--<p><font color="white"><font size=4><?php //echo $error;?></font></p>
  </form>
 <?php  
}
?>
</div>-->
</body>
</html>